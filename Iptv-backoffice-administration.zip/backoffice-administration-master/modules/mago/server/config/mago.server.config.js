'use strict';


/**
 * Module init function.
 */
module.exports = function(app, db) {

};